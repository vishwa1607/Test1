create table `databasetest`.`cinema`(`id` int auto_increment not null,
`movie` varchar(32) not null,
`description` varchar(48) not null,
`rating` float(10,2) not null,
primary key(`id`)
 );
 truncate table `databasetest`.`cinema`;
 Insert into `databasetest`.`cinema`(`movie`,`description`,`rating`)
 values('War','great 3D',8.9);
  Insert into `databasetest`.`cinema`(`movie`,`description`,`rating`)
 values('Science','fiction',8.5);
  Insert into `databasetest`.`cinema`(`id`,`movie`,`description`,`rating`)
 values(3,'irish','boring',6.2);
  Insert into `databasetest`.`cinema`(`movie`,`description`,`rating`)
 values('Ice song','Fantacy',8.6);
  Insert into `databasetest`.`cinema`(`id`,`movie`,`description`,`rating`)
 values(5,'House card','Interesting',9.1);
 select * from `databasetest`.`cinema` where mod(id,2)=1 and description!='boring'
 order by rating  DESC;
  Insert into `databasetest`.`cinema`(`id`,`movie`,`description`,`rating`)
 values(6,'House card','Interesting',12.1);
 delete table `databasetest`.`cinema` where id=6;