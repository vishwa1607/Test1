create schema `student`;
create table `student`.`studentDetails`(
`rollNo` int not null auto_increment,
`name` varchar(48) not null,
`phone` varchar(16) not null,
`dob` date not null,
primary key (`rollNo`)
 );
 
 create table `student`.`sem1`(
`id` int not null auto_increment,
`scienceGrade` varchar(8) not null,
`mathsGrade` varchar(8) not null,
`rollNo` int not null,
`finalGrade` varchar(8) not null,
primary key (`id`),
Foreign key(`rollNo`) references `student`.`studentDetails`(`rollNo`)
 );
 
 create table `student`.`sem2`(
`id` int not null auto_increment,
`englishGrade` varchar(8) not null,
`hindiGrade` varchar(8) not null,
`rollNum` int not null,
`finalGrade` varchar(8) not null,
primary key (`id`),
Foreign key(`rollNum`) references `student`.`studentDetails`(`rollNo`)
 );