CREATE TABLE `databasetest`.`indextable`(`id` int not null auto_increment,
`email` varchar(24) not null,
primary key(`id`)
);
create index i1 on `databasetest`.`indextable`(`email`);
show index from  `databasetest`.`indextable`;