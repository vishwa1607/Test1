create table `databasetest`.`salary`(`id` int auto_increment not null,
`name` varchar(32) not null,
`sex` enum('f','m') not null,
`salary` int not null,
primary key(`id`)
 );
 Insert into `databasetest`.`salary`(`name`,`sex`,`salary`)
 values('A','m',2500);
  Insert into `databasetest`.`salary`(`name`,`sex`,`salary`)
 values('B','f',1500);
  Insert into `databasetest`.`salary`(`name`,`sex`,`salary`)
 values('C','m',5500);
  Insert into `databasetest`.`salary`(`name`,`sex`,`salary`)
 values('D','f',500);
 select * from `databasetest`.`salary`;
  Insert into `databasetest`.`salary`(`name`,`sex`,`salary`)
 values('A','d',2500);
 update `databasetest`.`salary`SET sex='m' where sex='f';
 update `databasetest`.`salary` SET sex='f' where id=2;
 update `databasetest`.`salary` SET sex='f' where id=4;
 select * from `databasetest`.`salary`;
 UPDATE`databasetest`.`salary`
SET sex = if(sex = 'm', 'f', 'm');
select * from `databasetest`.`salary`;