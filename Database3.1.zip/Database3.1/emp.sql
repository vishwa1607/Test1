CREATE SCHEMA databasetest;
create table `databasetest`.`employee`(`empId` int auto_increment not null,
`empName` varchar(48) not null ,
`empsalay` double not null,
`empDob` date not null,
`empJoiningdate` date not null,
`Gender` varchar(8) not null,
`mobileNumber` varchar(16) not null,
primary key(`empId`) );
CREATE table `databasetest`.`department`(
`empID` INT NOT NULL,
`depID` INT NOT NULL AUTO_INCREMENT,
`depName`varchar(48)NOT NULL,
`designation` varchar(16)NOT NULL,
FOREIGN KEY (`empID`) REFERENCES `databasetest`.`employee`(`empID`),
PRIMARY KEY (`depID`)
);
CREATE table `databasetest`.`leave`(
`leaveID` INT NOT NULL,
`empID` INT NOT NULL,
`depID` INT NOT NULL,
`leaveStartDate` date NOT NULL ,
`leaveEndDate` date NOT NULL ,
`leaveType` varchar(48) NOT NULL,
FOREIGN KEY (`empID`) REFERENCES `databasetest`.`employee`(`empID`),
FOREIGN KEY (`depID`) REFERENCES `databasetest`.`department`(`depID`),
PRIMARY KEY (`leaveID`)
);