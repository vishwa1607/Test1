create table `section3.2`.`courses`(`student` varchar(16),`class` varchar(16));
Insert into `section3.2`.`courses`(`student`,`class`) values('A','Math');
Insert into `section3.2`.`courses`(`student`,`class`) values('B','English');
Insert into `section3.2`.`courses`(`student`,`class`) values('C','Math');
Insert into `section3.2`.`courses`(`student`,`class`) values('D','Biology');
Insert into `section3.2`.`courses`(`student`,`class`) values('E','Math');
Insert into `section3.2`.`courses`(`student`,`class`) values('F','Computer');
Insert into `section3.2`.`courses`(`student`,`class`) values('G','Math');
Insert into `section3.2`.`courses`(`student`,`class`) values('H','Math');
Insert into `section3.2`.`courses`(`student`,`class`) values('I','Math');
alter table `section3.2`.`courses`
Add primary key(`student`,`class`);
select `class` from `section3.2`.`courses`
group by class having count(distinct student)>5;