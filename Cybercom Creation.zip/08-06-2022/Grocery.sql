create schema `Grocery`;
create table `Grocery`.`Category`
(`categoryId` int auto_increment not null,
`categoryName` varchar(48) not null,
`categoryStatus` boolean not null,
`createdDate` date not null,
`updatedDate` date not null,
`isActive` boolean not null, 
primary key(`categoryId`));
create table `Grocery`.`Product`
(`productId` int auto_increment not null,
`productName` varchar(48) not null,
`productQuantity` int not null,
`productPrice` double not null,
`productWeight` double not null,
`productStatus` boolean not null,
`createdDate` date not null,
`updatedDate` date not null,
`sku` varchar(32) not null,
`isActive` boolean not null,
`uniqueId` varchar(32) not null,
`categoryId` int not null,
primary key(`productId`),
foreign key(`categoryId`) references `Grocery`.`Category`(`categoryId`) 
);
create table `Grocery`.`Users`
(`userID` int auto_increment not null,
`userFname` varchar(48) not null,
`userLname` varchar(48) not null,
`userEmail` varchar(48) not null,
`userMobilenumber` int(10) not null,
`userPassword` varchar(48) not null,
`userGender` enum('f','m','other') not null,
`userDob` date not null,
`isActive` boolean not null, 
primary key(`userID`));
create table `Grocery`.`Address`
(`addressId` int auto_increment not null,
`addressLine` varchar(48) not null,
`addressStreet` varchar(48) not null,
`addressDistrict` varchar(48) not null,
`addressCity` varchar(48) not null,
`addressState` varchar(48) not null,
`addressCountry` varchar(48) not null,
`userId` int not null,
`addressPincode` int not null,
`addressMobileNumber` double not null,
primary key(`addressId`),
foreign key(`userId`) references `Grocery`.`Users`(`userID`)
);
create table `Grocery`.`OrderAddress`
(`OrderaddressId` int auto_increment not null,
`userId` int not null,
`addressId` int not null,
`type` boolean not null,
primary key(`OrderaddressId`),
foreign key(`userId`) references `Grocery`.`Users`(`userID`),
foreign key(`addressId`) references `grocery`.`address`(`addressId`)
);
create table `Grocery`.`Order`
(`orderId` int auto_increment not null,
`userId` int not null,
`orderAmount` double not null,
`orderDate` date not null,
`orderStatus` boolean not null,
`paymentStatus` boolean not null,
`orderMobileNumber` double not null,
`orderaddressId` int not null,
primary key(`orderId`),
foreign key(`userId`) references `Grocery`.`Users`(`userID`),
foreign key(`orderaddressId`) references `Grocery`.`orderAddress`(`orderAddressId`)
);