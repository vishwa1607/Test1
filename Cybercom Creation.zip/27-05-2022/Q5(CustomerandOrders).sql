CREATE TABLE `databasetest`.`Customers`(`id` int not null auto_increment,
`name` varchar(24) not null,
primary key(`id`)
);
CREATE TABLE `databasetest`.`orders`(`id` int not null auto_increment,
`customerId` int not null,
primary key(`id`),
Foreign key(`customerId`) references `databasetest`.`Customers`(`id`)
);
Insert into `databasetest`.`Customers`(`name`) values('Joe');
Insert into `databasetest`.`Customers`(`name`) values('Henry');
Insert into `databasetest`.`Customers`(`name`) values('Sam');
Insert into `databasetest`.`Customers`(`name`) values('Max');
Insert into `databasetest`.`orders`(`customerId`) values(3);
Insert into `databasetest`.`orders`(`customerId`) values(1);