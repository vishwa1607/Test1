create schema `section3.2`;
create table `section3.2`.`activity`(
 `playerId` int not null ,
 `deviceId` int not null,
 `eventDate` date not null ,
 `gamesPlayed` int not null,
 primary key(`playerId` ,`eventDate`)
);
Insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesplayed`)values(1,2,'2016-03-01',5);
Insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesplayed`)values(1,2,'2016-05-02',6);
Insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesplayed`)values(2,3,'2017-06-25',1);
Insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesplayed`)values(3,1,'2016-03-02',0);
Insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesplayed`)values(3,4,'2018-07-03',5);
select `activity`.`playerId`,`activity`.`eventDate`
from `section3.2`.`activity`;
select playerId, min(eventDate) as first_login
from `section3.2`.`activity`
group by playerId;
select playerId, deviceId  
from `section3.2`.`activity`
group by playerId;

select playerId, eventDate, sum(gamesplayed) 
over(partition by playerId order by eventDate) 'games_played_so_far'
from `section3.2`.`activity`;
