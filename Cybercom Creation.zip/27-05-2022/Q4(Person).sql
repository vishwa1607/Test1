CREATE TABLE `databasetest`.`person3`(`id` int not null auto_increment,
`email` varchar(24) not null,
primary key(`id`)
);
Insert into `databasetest`.`person3`(`email`) values('john@example.com');
Insert into `databasetest`.`person3`(`email`) values('bob@example.com');
Insert into `databasetest`.`person3`(`email`) values('john@example.com');
delete from `databasetest`.`person3` where id not in (select * from (select min(id) from `databasetest`.`person3` group by email) as p);
select * from `databasetest`.`person3`;