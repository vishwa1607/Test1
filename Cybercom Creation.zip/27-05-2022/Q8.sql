CREATE TABLE `databasetest`.`person`(`personId` int not null auto_increment,
`lastname` varchar(24) not null,
`firstname` varchar(24) not null,
primary key(`personId`)
);
CREATE TABLE `databasetest`.`address`(`addressId` int not null auto_increment,
`personId` int  not null,
`city` varchar(24) not null,
`state` varchar(24) not null,
primary key(`addressId`),
foreign key(`personId`) references `databasetest`.`person`(`personId`)
);
Insert into `databasetest`.`person`(`lastname`,`firstname`) values('Wang','Allen');
Insert into `databasetest`.`person`(`lastname`,`firstname`) values('Alice','Bob');
Insert into `databasetest`.`person`(`lastname`,`firstname`) values('Shah','Vishwa');
Insert into `databasetest`.`address`(`personId`,`city`,`state`) values (2,'New Yourk City','New Yourk');
Insert into `databasetest`.`address`(`personId`,`city`,`state`) values (3,'LeetCode','California');
select `person`.`firstname`,`person`.`lastname`,`address`.`city`,`address`.`state`
from `databasetest`.`address`
right join `databasetest`.`person` on `person`.`personId`=`address`.`addressId`;
truncate table `databasetest`.`address`;
Insert into `databasetest`.`address`(`personId`,`city`,`state`) values (1,'New Yourk City','New Yourk');
Insert into `databasetest`.`address`(`personId`,`city`,`state`) values (2,'LeetCode','California');
select `person`.`firstname`,`person`.`lastname`,`address`.`city`,`address`.`state`
from `databasetest`.`address`
right join `databasetest`.`person` on `person`.`personId`=`address`.`addressId`;